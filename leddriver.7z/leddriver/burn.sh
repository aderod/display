avrdude -c avrisp2 -p atmega328p -e -U flash:w:bin/main.hex -B 10

